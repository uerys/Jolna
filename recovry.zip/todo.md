# Recovry — Project TODO

## Stack Decision
- [x] Path A confirmed: React/Vite + Express + tRPC + Drizzle + MySQL + Manus OAuth + shadcn/ui
- [x] Advisor consultation flagged to user; keep business logic portable

## 0. Foundation
- [x] Global theme + design tokens in `client/src/index.css` (clean clinical look)
- [x] Add shadcn components we need: Slider, Progress, Select, Tabs, Table, Toast, Badge, Dialog
- [x] Author notes: `docs/fyp-chapter3-diffs.md` — list everything Chapter 3 needs to change

## 1. Authentication & RBAC
- [x] Manus OAuth (replaces email/password + bcrypt per Path A discussion)
- [x] Extend role enum to `client | physiotherapist | admin` (admin == Clinic Admin)
- [x] Add account status field (`pending | active | suspended`)
- [x] `clientProcedure`, `physioProcedure`, `adminProcedure` helpers in tRPC
- [x] Role-aware `Home` page that redirects to the correct dashboard after login
- [x] Unit tests: each role helper rejects the wrong role

## 2. Database Schema (Drizzle + MySQL, dialect-portable style)
- [x] `users` — extend with `role`, `status`, `languagePreference`, `physiotherapistId` (FK for clients)
- [x] `exercises` — title, instructionsEn, instructionsKh, videoUrl, defaultReps, createdBy
- [x] `assignments` — exerciseId, physiotherapistId, clientId, reps, startDate, endDate, status
- [x] `feedbackLogs` — assignmentId, clientId, painScore (0–10), completed, notes, submittedAt
- [x] Generate migration SQL via drizzle-kit; apply with `drizzle-kit migrate`
- [x] Query helpers in `server/db.ts`
- [x] Seed demo data: 1 Clinic Admin, 1 Physiotherapist, 1 Client, 2 exercise templates, 2 assignments, 3 feedback logs

## 3. Localization (react-intl)
- [x] Install i18n library (react-intl)
- [x] Message catalogs: `client/src/i18n/messages/en.json`, `client/src/i18n/messages/kh.json`
- [x] Persist language preference in `users.languagePreference`
- [x] Language toggle component in top nav (EN / ខ្មែរ)
- [x] All UI strings localized via `<FormattedMessage />` or `intl.formatMessage`

## 4. Clinic Admin — User Management
- [x] `/admin/users` page with filter by role
- [x] Approve / Suspend / Delete
- [x] Edit dialog (name, email, role, status, physiotherapist assignment)

## 5. Physiotherapist — Exercise Management
- [x] `/physio` Exercises tab: list / create / edit / delete
- [x] Form fields: title, instructionsEn, instructionsKh, videoUrl, defaultReps
- [x] Assign exercise to client: pick client, reps, startDate, endDate
- [x] List and manage active assignments

## 6. Client — Exercise Access
- [x] `/client/today` listing today's active assignments
- [x] Embedded video + bilingual instructions based on `languagePreference`

## 7. Client — Feedback Submission
- [x] Daily feedback dialog per assignment
- [x] Pain slider 0–10 with live colour-coded label
- [x] Completion toggle (Switch)
- [x] Optional notes textarea
- [x] `/client/history` with chart + stats

## 8. Physiotherapist — Monitoring Dashboard
- [x] Client roster (clients assigned to the physio) with completion %
- [x] Per-client detail page: pain trend + session history
- [x] Monitoring overview: aggregate pain trend, high-pain alerts, totals

## 9. UI Shell
- [x] `AppShell` with responsive top bar
- [x] Language toggle pinned in top bar for all roles
- [x] Dev-only impersonation dropdown visible only to Clinic Admin

## 10. Testing
- [x] Vitest: RBAC enforcement across admin / physio / clientApp routers
- [x] Vitest: pain score validation (0–10)
- [x] Vitest: language preference input validation
- [x] Updated `auth.logout.test.ts` to expect impersonation cookie clearing
- [x] `pnpm test` passes (12 passed / 0 failed)

## 11. Delivery
- [x] Save checkpoint (v735eec7f)
- [x] Write `/home/ubuntu/FYP_Chapter3_Diffs.md` with the exact edits needed in Chapter 3
- [x] Push to branch `manus-implementation` on `Kuyhavtea/recovry` fork
- [x] Deliver preview link + summary to user

## 12. Dev Impersonation (demo-only)
- [x] `impersonatedUserId` cookie overrides `ctx.user` in development
- [x] tRPC procedure `dev.impersonate({ userId })` admin-only, dev-mode-only
- [x] tRPC procedure `dev.stopImpersonation()` admin-only, dev-mode-only
- [x] Top-bar role switcher visible when user is admin (select among seeded users)
- [x] Production impersonation disabled (server rejects the mutation)


## 13. Bug Fixes (post-delivery)
- [x] Silence react-intl MISSING_DATA warning for Khmer locale (IntlProvider onError). Note: we did **not** polyfill Khmer CLDR data; numeric/date formatting falls back to English formatting while message text remains fully Khmer. Acceptable because no part of the UI renders locale-specific numbers or dates beyond `toLocaleDateString`, which browsers already ship Khmer data for.
- [x] Physio, Client Today, and Client History pages now redirect non-matching roles via useEffect + navigate() before any protected tRPC query is made; the `enabled` flag on the queries also prevents the FORBIDDEN call. New i18n keys `physio.dashboard.onlyPhysio` / `client.today.onlyClient` added in EN and KH. Verified in live preview: browsing to /admin/users as the Clinic Admin loads cleanly without any toast errors.
- [x] Re-ran vitest: 12 passed / 0 failed
