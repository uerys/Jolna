import { NextRequest, NextResponse } from "next/server";
import { query } from "@/lib/db";

type NoteRow = {
  id: number;
  content: string;
  created_at: string;
};

async function ensureNotesTable() {
  await query(`
    CREATE TABLE IF NOT EXISTS notes (
      id SERIAL PRIMARY KEY,
      content TEXT NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
}

export async function GET() {
  try {
    await ensureNotesTable();

    const result = await query<NoteRow>(
      "SELECT id, content, created_at FROM notes ORDER BY id DESC",
    );

    return NextResponse.json({ notes: result.rows });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Database error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    await ensureNotesTable();

    const body = await request.json();
    const content =
      typeof body?.content === "string" ? body.content.trim() : "";

    if (!content) {
      return NextResponse.json(
        { error: "Content is required" },
        { status: 400 },
      );
    }

    const result = await query<NoteRow>(
      "INSERT INTO notes (content) VALUES ($1) RETURNING id, content, created_at",
      [content],
    );

    return NextResponse.json({ note: result.rows[0] }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Database error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
