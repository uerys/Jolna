import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { IMPERSONATE_COOKIE, publicProcedure, router } from "./_core/trpc";
import { getUserById } from "./db";
import { adminRouter } from "./routers/admin";
import { clientRouter } from "./routers/client";
import { devRouter } from "./routers/dev";
import { physioRouter } from "./routers/physio";
import { settingsRouter } from "./routers/settings";
import { parse as parseCookieHeader } from "cookie";

/**
 * Resolve effective user (respects dev-mode impersonation) for auth.me.
 */
async function resolveEffectiveMe(ctx: {
  user: Awaited<ReturnType<typeof getUserById>> | null | undefined;
  req: { headers: { cookie?: string } };
}) {
  if (!ctx.user) return null;
  if (process.env.NODE_ENV === "production") return ctx.user;
  const cookieHeader = ctx.req.headers?.cookie;
  if (!cookieHeader) return ctx.user;
  const parsed = parseCookieHeader(cookieHeader);
  const raw = parsed[IMPERSONATE_COOKIE];
  if (!raw) return ctx.user;
  const id = Number.parseInt(raw, 10);
  if (!Number.isFinite(id)) return ctx.user;
  if (ctx.user.role !== "admin") return ctx.user;
  const impersonated = await getUserById(id);
  return impersonated ?? ctx.user;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(async (opts) => {
      const effective = await resolveEffectiveMe(opts.ctx);
      if (!effective) return null;
      // Surface whether the user is currently being impersonated so the UI
      // can show a "Viewing as …" banner.
      const rawCookie = opts.ctx.req.headers?.cookie ?? "";
      const impersonating =
        process.env.NODE_ENV !== "production" &&
        opts.ctx.user?.role === "admin" &&
        !!parseCookieHeader(rawCookie)[IMPERSONATE_COOKIE];
      return { ...effective, __impersonating: impersonating } as typeof effective & {
        __impersonating: boolean;
      };
    }),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      ctx.res.clearCookie(IMPERSONATE_COOKIE, { path: "/" });
      return { success: true } as const;
    }),
  }),
  admin: adminRouter,
  physio: physioRouter,
  clientApp: clientRouter,
  dev: devRouter,
  settings: settingsRouter,
});

export type AppRouter = typeof appRouter;
