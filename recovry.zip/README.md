# Recovry (Next.js + PostgreSQL + Docker)

Minimal full-stack setup:

- Next.js App Router
- PostgreSQL in Docker

## 1) Environment

`.env.local` is already configured with:

```bash
DATABASE_URL=postgresql://postgres:password@localhost:5432/appdb
```

## 2) Start PostgreSQL

```bash
npm run db:up
```

Check logs if needed:

```bash
npm run db:logs
```

Stop database:

```bash
npm run db:down
```

## 3) Start Next.js

```bash
npm run dev
```

Open `http://localhost:3000`.

## 4) API Endpoints

- `GET /api/health` - checks database connectivity
- `GET /api/notes` - list notes
- `POST /api/notes` - create note with JSON body:

```json
{ "content": "hello" }
```

## PostgreSQL Interface Access

```bash
npm run db:psql
```
