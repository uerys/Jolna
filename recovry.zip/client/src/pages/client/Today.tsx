import { useEffect, useMemo, useState } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import AppShell from "@/components/AppShell";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { useI18n } from "@/contexts/I18nContext";
import { useAuth } from "@/_core/hooks/useAuth";
import { CalendarDays, History } from "lucide-react";

export default function ClientToday() {
  const { user, loading } = useAuth();
  const { language } = useI18n();
  const [, navigate] = useLocation();

  const isClient = !!user && (user.role === "client" || user.role === "user");

  // Only run the protected query when the caller really is a client —
  // otherwise tRPC returns FORBIDDEN and toasts a scary error.
  const today = trpc.clientApp.listTodayAssignments.useQuery(undefined, {
    enabled: !loading && isClient,
  });

  useEffect(() => {
    if (loading || !user) return;
    if (user.role === "admin") {
      navigate("/admin/users", { replace: true });
    } else if (user.role === "physiotherapist") {
      navigate("/physio", { replace: true });
    }
  }, [loading, user, navigate]);

  if (!loading && user && !isClient) {
    return (
      <AppShell>
        <Card>
          <CardHeader>
            <CardTitle><FormattedMessage id="common.notAuthorised" /></CardTitle>
            <CardDescription><FormattedMessage id="client.today.onlyClient" /></CardDescription>
          </CardHeader>
        </Card>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <CalendarDays className="size-6 text-primary" />
          <div>
            <h1 className="text-2xl font-semibold tracking-tight">
              <FormattedMessage id="client.today.title" />
            </h1>
            <p className="text-sm text-muted-foreground">
              <FormattedMessage id="client.today.subtitle" />
            </p>
          </div>
        </div>
        <Button asChild variant="outline" size="sm">
          <Link href="/client/history">
            <History className="size-4 mr-1" />
            History
          </Link>
        </Button>
      </div>

      <div className="mt-6 space-y-4">
        {today.isLoading && <div className="text-muted-foreground"><FormattedMessage id="common.loading" /></div>}
        {!today.isLoading && (today.data?.length ?? 0) === 0 && (
          <Card><CardContent className="pt-6 text-muted-foreground"><FormattedMessage id="client.today.noAssignments" /></CardContent></Card>
        )}
        {today.data?.map((row) => (
          <ExerciseCard
            key={row.assignment.id}
            language={language}
            assignment={row.assignment}
            exercise={row.exercise}
          />
        ))}
      </div>
    </AppShell>
  );
}

function ExerciseCard({
  assignment,
  exercise,
  language,
}: {
  assignment: { id: number; reps: number };
  exercise: { id: number; title: string; instructionsEn: string; instructionsKh: string; videoUrl: string };
  language: "en" | "kh";
}) {
  const instructions = language === "kh" ? exercise.instructionsKh : exercise.instructionsEn;
  const [open, setOpen] = useState(false);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between gap-3">
          <CardTitle className="text-lg">{exercise.title}</CardTitle>
          <Badge variant="secondary">
            <FormattedMessage id="client.today.reps" values={{ reps: assignment.reps }} />
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)] gap-4">
          <div className="aspect-video rounded-md overflow-hidden bg-muted">
            <iframe
              src={exercise.videoUrl}
              title={exercise.title}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
          <div>
            <p className="text-sm whitespace-pre-wrap leading-relaxed">{instructions}</p>
            <Button className="mt-4 w-full" onClick={() => setOpen(true)}>
              <FormattedMessage id="client.today.logFeedback" />
            </Button>
          </div>
        </div>
      </CardContent>
      <FeedbackDialog
        assignmentId={assignment.id}
        open={open}
        onClose={() => setOpen(false)}
      />
    </Card>
  );
}

function FeedbackDialog({ assignmentId, open, onClose }: { assignmentId: number; open: boolean; onClose: () => void }) {
  const intl = useIntl();
  const utils = trpc.useUtils();
  const submit = trpc.clientApp.submitFeedback.useMutation({
    onSuccess: async () => {
      await utils.clientApp.listMyFeedback.invalidate();
      toast.success(intl.formatMessage({ id: "client.feedback.submitted" }));
      onClose();
    },
  });

  const [painScore, setPainScore] = useState<number>(3);
  const [completed, setCompleted] = useState<boolean>(true);
  const [notes, setNotes] = useState<string>("");

  const painColor = useMemo(() => {
    if (painScore >= 7) return "text-destructive";
    if (painScore >= 4) return "text-amber-600";
    return "text-emerald-600";
  }, [painScore]);

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle><FormattedMessage id="client.today.logFeedback" /></DialogTitle>
        </DialogHeader>
        <div className="space-y-5">
          <div>
            <div className="flex items-center justify-between">
              <Label><FormattedMessage id="client.feedback.painScore" /></Label>
              <span className={`font-semibold ${painColor}`}>{painScore} / 10</span>
            </div>
            <Slider
              className="mt-3"
              min={0}
              max={10}
              step={1}
              value={[painScore]}
              onValueChange={(v) => setPainScore(v[0] ?? 0)}
            />
            <p className="text-xs text-muted-foreground mt-1">
              <FormattedMessage id="client.feedback.painHint" />
            </p>
          </div>

          <div className="flex items-center justify-between border rounded-md p-3">
            <Label className="cursor-pointer"><FormattedMessage id="client.feedback.completed" /></Label>
            <Switch checked={completed} onCheckedChange={setCompleted} />
          </div>

          <div>
            <Label><FormattedMessage id="client.feedback.notes" /></Label>
            <Textarea rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}><FormattedMessage id="common.cancel" /></Button>
          <Button
            onClick={() =>
              submit.mutate({
                assignmentId,
                painScore,
                completed,
                notes: notes || undefined,
              })
            }
          >
            <FormattedMessage id="client.feedback.submit" />
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
