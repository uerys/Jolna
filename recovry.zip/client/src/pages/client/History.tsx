import { useEffect } from "react";
import { FormattedMessage } from "react-intl";
import { useLocation } from "wouter";
import AppShell from "@/components/AppShell";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { History as HistoryIcon } from "lucide-react";

export default function ClientHistory() {
  const { user, loading } = useAuth();
  const [, navigate] = useLocation();
  const isClient = !!user && (user.role === "client" || user.role === "user");

  const feedback = trpc.clientApp.listMyFeedback.useQuery(undefined, {
    enabled: !loading && isClient,
  });
  const stats = trpc.clientApp.myStats.useQuery(undefined, {
    enabled: !loading && isClient,
  });

  useEffect(() => {
    if (loading || !user) return;
    if (user.role === "admin") navigate("/admin/users", { replace: true });
    else if (user.role === "physiotherapist") navigate("/physio", { replace: true });
  }, [loading, user, navigate]);

  if (!loading && user && !isClient) {
    return (
      <AppShell>
        <Card>
          <CardHeader>
            <CardTitle><FormattedMessage id="common.notAuthorised" /></CardTitle>
            <CardDescription><FormattedMessage id="client.today.onlyClient" /></CardDescription>
          </CardHeader>
        </Card>
      </AppShell>
    );
  }

  const chartData = (feedback.data ?? [])
    .slice()
    .reverse()
    .map((f) => ({
      date: new Date(f.submittedAt).toLocaleDateString(),
      pain: f.painScore,
    }));

  const rate = stats.data?.total
    ? Math.round((stats.data.completed / stats.data.total) * 100)
    : 0;

  return (
    <AppShell>
      <div className="flex items-center gap-3">
        <HistoryIcon className="size-6 text-primary" />
        <h1 className="text-2xl font-semibold tracking-tight">History</h1>
      </div>

      <div className="grid md:grid-cols-2 gap-4 mt-6">
        <Card>
          <CardHeader>
            <CardTitle><FormattedMessage id="physio.monitor.painTrend" /></CardTitle>
          </CardHeader>
          <CardContent className="h-60">
            {chartData.length === 0 ? (
              <div className="text-sm text-muted-foreground"><FormattedMessage id="physio.monitor.noData" /></div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="date" stroke="currentColor" fontSize={12} />
                  <YAxis domain={[0, 10]} stroke="currentColor" fontSize={12} />
                  <Tooltip />
                  <Line type="monotone" dataKey="pain" stroke="hsl(var(--primary))" strokeWidth={2} dot />
                </LineChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle><FormattedMessage id="physio.monitor.completion" /></CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-semibold">{rate}%</div>
            <p className="text-sm text-muted-foreground mt-1">
              {stats.data?.completed ?? 0} / {stats.data?.total ?? 0} sessions completed
            </p>
          </CardContent>
        </Card>
      </div>

      <Card className="mt-4">
        <CardHeader>
          <CardTitle><FormattedMessage id="physio.monitor.history" /></CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Pain</TableHead>
                <TableHead>Completed</TableHead>
                <TableHead>Notes</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(feedback.data ?? []).length === 0 && (
                <TableRow>
                  <TableCell colSpan={4} className="text-center text-muted-foreground py-6">
                    <FormattedMessage id="physio.monitor.noData" />
                  </TableCell>
                </TableRow>
              )}
              {feedback.data?.map((f) => (
                <TableRow key={f.id}>
                  <TableCell className="text-sm text-muted-foreground">
                    {new Date(f.submittedAt).toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <Badge variant={f.painScore >= 7 ? "destructive" : f.painScore >= 4 ? "secondary" : "default"}>
                      {f.painScore}/10
                    </Badge>
                  </TableCell>
                  <TableCell>{f.completed ? "✓" : "—"}</TableCell>
                  <TableCell className="text-sm">{f.notes ?? ""}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </AppShell>
  );
}
