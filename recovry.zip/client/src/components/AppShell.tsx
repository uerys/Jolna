import { ReactNode } from "react";
import { FormattedMessage, useIntl } from "react-intl";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { LanguageToggle } from "@/components/LanguageToggle";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { Activity, LogOut } from "lucide-react";

type Props = {
  children: ReactNode;
  sidebar?: ReactNode;
};

function roleToKey(role: string | undefined) {
  switch (role) {
    case "admin":
      return "role.admin";
    case "physiotherapist":
      return "role.physiotherapist";
    case "client":
    case "user":
      return "role.client";
    default:
      return "role.client";
  }
}

export default function AppShell({ children, sidebar }: Props) {
  const { user, isAuthenticated, logout } = useAuth();
  const [, navigate] = useLocation();
  const intl = useIntl();

  const impersonating = (user as { __impersonating?: boolean } | null)?.__impersonating;
  const utils = trpc.useUtils();
  const targets = trpc.dev.listImpersonationTargets.useQuery(undefined, {
    // Only meaningful for admins — but the server silently returns [] otherwise.
    enabled: !!user,
  });
  const impersonate = trpc.dev.impersonate.useMutation({
    onSuccess: async () => {
      await utils.auth.me.invalidate();
      navigate("/");
    },
  });
  const stopImpersonation = trpc.dev.stopImpersonation.useMutation({
    onSuccess: async () => {
      await utils.auth.me.invalidate();
      navigate("/");
    },
  });

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b bg-card/60 backdrop-blur sticky top-0 z-30">
        <div className="container flex items-center gap-3 py-3">
          <Link
            href="/"
            className="flex items-center gap-2 font-semibold text-lg tracking-tight"
          >
            <Activity className="size-5 text-primary" />
            <FormattedMessage id="app.name" />
          </Link>

          <div className="flex-1" />

          <LanguageToggle />

          {isAuthenticated ? (
            <>
              {impersonating && (
                <Badge variant="secondary" className="gap-1">
                  <FormattedMessage
                    id="nav.viewingAs"
                    values={{
                      name: user?.name ?? "",
                      role: intl.formatMessage({ id: roleToKey(user?.role) }),
                    }}
                  />
                </Badge>
              )}

              {/* Dev-only impersonation dropdown (visible only when targets list is non-empty
                  — the server returns empty in production or for non-admins). */}
              {(targets.data?.length ?? 0) > 0 && (
                <Select
                  onValueChange={(v) => {
                    if (v === "__stop") {
                      stopImpersonation.mutate();
                      return;
                    }
                    impersonate.mutate({ userId: Number(v) });
                  }}
                >
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="Impersonate…" />
                  </SelectTrigger>
                  <SelectContent>
                    {impersonating && (
                      <SelectItem value="__stop">
                        {intl.formatMessage({ id: "nav.stopImpersonation" })}
                      </SelectItem>
                    )}
                    {targets.data?.map((t) => (
                      <SelectItem key={t.id} value={String(t.id)}>
                        {t.name ?? t.email ?? `#${t.id}`} —{" "}
                        {intl.formatMessage({ id: roleToKey(t.role) })}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}

              <div className="hidden sm:flex flex-col text-right leading-tight">
                <span className="text-sm font-medium">{user?.name ?? user?.email ?? "—"}</span>
                <span className="text-xs text-muted-foreground">
                  <FormattedMessage id={roleToKey(user?.role)} />
                </span>
              </div>
              <Button variant="outline" size="sm" onClick={() => logout()}>
                <LogOut className="size-4 mr-1" />
                <FormattedMessage id="nav.signOut" />
              </Button>
            </>
          ) : (
            <Button asChild size="sm">
              <a href={getLoginUrl()}>
                <FormattedMessage id="nav.signIn" />
              </a>
            </Button>
          )}
        </div>
      </header>

      <div className="flex-1 flex">
        {sidebar && (
          <aside className="hidden md:block w-60 border-r bg-card/40 p-4 shrink-0">
            {sidebar}
          </aside>
        )}
        <main className="flex-1 min-w-0">
          <div className="container py-6">{children}</div>
        </main>
      </div>
    </div>
  );
}
