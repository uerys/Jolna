import { useI18n } from "@/contexts/I18nContext";
import { Button } from "@/components/ui/button";

export function LanguageToggle() {
  const { language, setLanguage } = useI18n();
  return (
    <div className="inline-flex items-center rounded-md border overflow-hidden" role="group" aria-label="Language">
      <Button
        variant={language === "en" ? "default" : "ghost"}
        size="sm"
        className="rounded-none px-3"
        onClick={() => setLanguage("en")}
      >
        EN
      </Button>
      <Button
        variant={language === "kh" ? "default" : "ghost"}
        size="sm"
        className="rounded-none px-3 font-medium"
        onClick={() => setLanguage("kh")}
      >
        ខ្មែរ
      </Button>
    </div>
  );
}
