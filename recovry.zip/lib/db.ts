import { Pool, QueryResult, QueryResultRow } from "pg";

declare global {
  var pgPool: Pool | undefined;
}

function getPool(): Pool {
  const connectionString = process.env.DATABASE_URL;

  if (!connectionString) {
    throw new Error("DATABASE_URL is not set. Add it to .env.local.");
  }

  if (!globalThis.pgPool) {
    globalThis.pgPool = new Pool({ connectionString });
  }

  return globalThis.pgPool;
}

export function query<T extends QueryResultRow = QueryResultRow>(
  text: string,
  params: unknown[] = [],
): Promise<QueryResult<T>> {
  return getPool().query<T>(text, params);
}
